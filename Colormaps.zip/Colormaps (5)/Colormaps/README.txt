DISCLAIMER:

The author of this Matlab File Exchange submission has not created any of the colormaps.

Parula has been taken from Matlab >=2014b

py_A-D has been taken from the discussion of the new colormaps for matlplotlib library in python.

Read more about colormaps on python: https://bids.github.io/colormap/